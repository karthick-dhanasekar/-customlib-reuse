/* global QUnit */

sap.ui.require(["com/mobo/printreusablee/print/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
