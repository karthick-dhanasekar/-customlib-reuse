sap.ui.define([
	"commoboprintreusablee/print/test/unit/controller/print.controller"
], function () {
	"use strict";
});
